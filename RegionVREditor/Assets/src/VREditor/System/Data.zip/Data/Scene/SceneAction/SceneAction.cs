﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;


namespace Babel.System.Data
{
    public class SceneAction
    {
        //Json Saved Data
        [JsonPropertyAttribute]
        [JsonConverter(typeof(StringEnumConverter))]
        public Flag action_flag = Flag.None;


        public object[] parameters_list;

        public SceneAction()
        {



        }

        public SceneAction(SceneAction.Flag f)
        {
            this.action_flag = f;


            switch (this.action_flag)
            {
                case Flag.None:
                    break;
                case Flag.SetCameraOrientation:
                    parameters_list = new object[3];
                    break;
                case Flag.SetVideo:
                    parameters_list = new object[1];
                    break;
                case Flag.PlayAudio:
                    parameters_list = new object[1];
                    break;
                case Flag.SwitchSceneDefault:
                    parameters_list = new object[1];
                    break;
                case Flag.SwitchSceneMaxGazingTime:
                    parameters_list = new object[1];
                    break;
                case Flag.SwitchSceneMinGazingTime:
                    parameters_list = new object[1];
                    break;
                case Flag.SwitchSceneLastSeenRegion:
                    parameters_list = new object[1];
                    break;
                case Flag.SwitchSceneFirstSeenRegion:
                    parameters_list = new object[1];
                    break;
                case Flag.SwitchSceneSeenAt:
                    parameters_list = new object[1];
                    break;
                case Flag.SwitchSceneRandom:
                    parameters_list = new object[1];
                    break;
                case Flag.RegionJumpToScene:
                    parameters_list = new object[1];
                    break;
                case Flag.RegionToAction:
                    parameters_list = new object[1];
                    break;
                case Flag.TimeToScene:
                    parameters_list = new object[1];
                    break;
                case Flag.TimeToAction:
                    parameters_list = new object[1];
                    break;
            }
        }

        public override string ToString()
        {
            return "Action Flag:" + action_flag;
        }
        public enum Flag : int
        {
            None = 0,
            SetCameraOrientation = 1,
            SetVideo = 2,
            PlayAudio = 3,
            SwitchSceneDefault = 4,
            SwitchSceneMaxGazingTime = 5,
            SwitchSceneMinGazingTime = 6,
            SwitchSceneLastSeenRegion = 7,
            SwitchSceneFirstSeenRegion = 8,
            SwitchSceneSeenAt = 9,
            SwitchSceneRandom = 10,
            RegionJumpToScene = 11,
            RegionJumpToShot = 12,
            RegionToAction = 13,
            TimeToScene = 14,
            TimeToAction = 15,
            TimeToShot = 16

        }


    }

}