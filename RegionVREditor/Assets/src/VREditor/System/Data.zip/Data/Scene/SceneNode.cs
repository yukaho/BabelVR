﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using Newtonsoft.Json;

namespace Babel.System.Data
{
    public class SceneNode
    {

        public static int factory_id = 0;


        //properties
        [JsonPropertyAttribute]
        public int id;   //scene object id

        [JsonPropertyAttribute]
        public string s_name;   //scene name

        [JsonPropertyAttribute]
        public List<SceneAction> initailize_actions; //actions of initialization stage

        [JsonPropertyAttribute]
        public List<SceneAction> running_actions; //actions of running stage

        [JsonPropertyAttribute]
        public List<SceneAction> end_actions; //actions of end stage

        [JsonPropertyAttribute]
        public float graph_pos_x; //graph position x

        [JsonPropertyAttribute]
        public float graph_pos_y; //graph position y

        [JsonPropertyAttribute]
        public List<String> movie_list;

        [JsonPropertyAttribute]
        public int current_movie_index;


        public SceneNode()
        {

            //register
            id = factory_id;
            factory_id++;

            //name
            s_name = "Scene Node ID: " + id;


            //initialize
            initailize_actions = new List<SceneAction>();
            running_actions = new List<SceneAction>();
            end_actions = new List<SceneAction>();
            movie_list = new List<string>();
            current_movie_index = 0;

            movie_list.Add("EMPTY");
            movie_list.Add("EMPTY");
            movie_list.Add("EMPTY");




        }


        public override string ToString()
        {
            string str = s_name + "\n";


            str += "Initialization Stage:\n";
            foreach (SceneAction sa in initailize_actions)
            {
                str += ">" + sa + "\n";
            }

            str += "Running Stage:\n";
            foreach (SceneAction sa in running_actions)
            {
                str += ">" + sa + "\n";
            }

            str += "End Stage:\n";
            foreach (SceneAction sa in end_actions)
            {
                str += ">" + sa + "\n";
            }

            return str;

        }

        public void reset()
        {
            initailize_actions.Clear();
            running_actions.Clear();
            end_actions.Clear();
        }

        public bool addSceneAction()
        {
            return false;
        }

        public void setGraphPosition(Vector3 post)
        {
            graph_pos_x = post.x;
            graph_pos_y = post.y;
        }

        public Vector3 getGraphPosition()
        {
            return new Vector3(graph_pos_x, graph_pos_y, 0);
        }
    }
}
