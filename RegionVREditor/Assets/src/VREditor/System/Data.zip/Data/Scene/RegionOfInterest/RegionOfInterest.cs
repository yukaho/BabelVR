﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using Newtonsoft.Json;


namespace Babel.System.Data
{
   
    public class RegionOfInterest
    {
        [JsonPropertyAttribute]
        SimpleVector3[] vertics;

        //[JsonIgnore]
        //Vector3[] vertics_unity;

        //[JsonIgnore]
        //public Mesh mesh;

        //[JsonIgnore]
        //public Material material;

        //[JsonIgnore]
        //Vector2[] uv;

        //[JsonIgnore]
        //int[] newTriangles;


        public RegionOfInterest()
        {


        }

        public void Start()
        {
            Debug.Log("#MESH");
            vertics = new SimpleVector3[4];
            //vertics_unity = new Vector3[4];
            vertics[0] = new SimpleVector3(-5, 5, 0);
            vertics[1] = new SimpleVector3(5, 5, 0);
            vertics[2] = new SimpleVector3(-5, -5, 0);
            vertics[3] = new SimpleVector3(5, -5, 0);


            //for (int i = 0; i < vertics.Length; i++)
            //{
            //    vertics_unity[i] = vertics[i].getUnityVector3();
            //}


            //Vector2[] uv = new Vector2[4];
            //uv[0] = new Vector2(0, 0);
            //uv[1] = new Vector2(1, 0);
            //uv[2] = new Vector2(0, 1);
            //uv[3] = new Vector2(1, 1);

            //newTriangles = new int[6];
            //newTriangles[0] = 0;
            //newTriangles[1] = 2;
            //newTriangles[2] = 1;

            //newTriangles[3] = 2;
            //newTriangles[4] = 3;
            //newTriangles[5] = 1;


            //mesh = new Mesh();
            //GetComponent<MeshFilter>().mesh = mesh;

            //mesh.vertices = vertics_unity;
            //mesh.uv = uv;
            //mesh.triangles = newTriangles;

            //mesh.name = "Generated Mesh";
        }


        public void Update()
        {
            // will make the mesh appear in the scene at origin position
            //Graphics.DrawMesh(mesh, this.transform.position, this.transform.rotation, material, 0);
        }
    }


}